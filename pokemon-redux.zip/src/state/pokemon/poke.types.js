export const pokeTyles = {
    SET_POKE_DATA: "SET_POKE_DATA",
    SET_POKYNAME :'SET_POKYNAME'
};

