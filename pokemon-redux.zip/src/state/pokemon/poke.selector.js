// export const IsSearchByImg = state => state.pokemon.searchByImg;
export const getPokyName = state => state.pokemon.pokyName;
