export const APIDATA = "apiData"
export const POKYNAME = "pokyName"
export const POKYDETAIL = "pokyDetail"
export const SQUADADD = "squadAdd"
export const SQUADDATA = "squadData"
export const DELETEDATA = "deleteData"
// export const POKEMON = 'displayPokemon'