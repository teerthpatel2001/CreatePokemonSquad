import React from 'react'

export default function Title() {
  return (
    <div>
      <h1>Select a Pokemon</h1>
    </div>
  )
}
